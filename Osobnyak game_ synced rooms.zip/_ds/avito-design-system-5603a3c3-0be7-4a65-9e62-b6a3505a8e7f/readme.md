# Avito Услуги — «Рассылки. Школьники и Родители» Design System

A brand and creative system reconstructed from one production campaign package:
the **Avito Услуги** (Avito Services) CRM + display campaign *«Рассылки. Школьники
и Родители»* — "Email sends: Schoolkids and Parents" — promoting the marketplace's
tutor category (репетиторы) ahead of the Russian ОГЭ / ЕГЭ school exams.

## Sources

- **Attached local codebase folder:** `TOLKUNOV x AVITO Услуги «Рассылки. Школьники и Родители»/`
  — a delivery package of ~90 flattened image files. **No source code, no Figma
  file, no design-token file and no font binaries were supplied.**
- No Figma links, GitHub repositories or slide decks were provided.
- Everything in this system was derived by reading those images: colours were
  pixel-sampled, type sizes and insets were measured from the rendered artboards,
  and the cut-out 3D renders and the logo lockup were extracted programmatically.

Attribution in the folder name suggests the package was produced by **TOLKUNOV**
for **Avito Услуги**. Treat the artwork as licensed campaign material.

### What the package contained

| Group | Files | What it is |
|---|---|---|
| `1400x500-*.jpg` | 5 finished + 6 artwork-only + size-label cards | Wide display banner, five copy concepts |
| `1400x712-*.jpg` | 4 finished + label cards | Taller display banner, same concepts |
| `960x960-*.png` | 6 | Circular illustration scenes on transparency, artwork only |
| `Шапка.jpg`, `Шапка-1.jpg` | 2 | The email header block ("шапка"), 1305×663, two audience variants |
| `Молния`, `Лупа`, `Шайба`, `Скейт`, `Блокнот` `.png` | ~30 (size variants) | Cut-out 3D objects on transparency |
| `Вариант 1–3`, `Макет 1`, `Школьники / Родители — Итерация 1` | — | Plain black-on-white **caption cards** the studio used to label sections of the presentation. No design content. |

## Products / surfaces represented

There is no app or website in the package. Two output surfaces exist:

1. **Promo banners** — paid/display placements at 1400×500 and 1400×712, plus a
   960×960 square that carries **artwork only, no type**.
2. **Email campaign («Рассылка»)** — a header block at 1305×663 in two audience
   cuts, *Родители* (parents) and *Школьники* (schoolkids). Only the header was
   delivered; the body of the email was not.

---

## CONTENT FUNDAMENTALS

**Language.** Russian only. Ё is always written out (`Ещё`, `ребёнку`) — never
collapsed to е.

**Voice — second person, plural-polite, and never about "us".** Copy addresses
one parent directly as *вы* in its polite imperative form: «Посмотрите
объявления и выберите преподавателя для ребёнка». The brand never says «мы»,
never says «наши репетиторы», and never claims a benefit for itself. The subject
of every sentence is the reader or the reader's child.

**Casing.** Sentence case everywhere. Headlines have **no terminal period**:
«Сезон экзаменов», «Найти репетитора», «За знаниями». Body sentences also drop
the final period when they are the last line of a block. All-caps appears only
in the exam acronyms **ОГЭ / ЕГЭ**.

**Headline shape.** Two to three words, one or two lines, no verb-heavy phrasing.
Two patterns account for all six observed headlines:
- *time pressure* — «Экзамены близко», «Скоро экзамены», «Перед экзаменами», «Сезон экзаменов»
- *the action itself, as an infinitive or a prepositional phrase* — «Найти репетитора», «За знаниями», «Подготовка к экзаменам»

**Body shape.** One sentence, 8–16 words, hand-broken across 2–3 lines so no line
runs long. It always does one of two jobs: state that there is still time
(«Ещё есть время найти репетитора и подготовиться к школьным предметам») or say
where to do it («…преподавателя можно выбрать на Авито Услугах»).

**The product name is written two ways, deliberately.** The logo lockup is the
Latin **Avito Услуги**. Inside body copy the name is Cyrillic and declined
naturally: «на Авито Услугах». Never mix — no «на Avito Услугах».

**Softeners the brand uses:** «Самое время…», «Ещё есть время…», «Если хочется…»,
«Если ребёнку нужно…». Conditional and permissive, never urgent-imperative. There
is no countdown, no "hurry", no discount language, no exclamation mark anywhere in
the package.

**Vocabulary.** «репетитор», «преподаватель», «подтянуть знания», «прокачать
знания», «школьные предметы», «подготовка к ОГЭ и ЕГЭ». Note *прокачать* — one
mildly colloquial gamer-adjacent verb is permitted; nothing more slangy than that.

**Pills are labels, not buttons.** «Репетитор», «ОГЭ/ЕГЭ» — one or two words,
naming the category and the exam. They carry no verb and never say "подробнее".

**No emoji. Anywhere.** The package contains none. Do not introduce them.

**Vibe:** calm, competent, parental. The campaign is reassurance, not
pressure — a service that happens to be ready when you need it.

---

## VISUAL FOUNDATIONS

### Colour

Two systems coexist. The **brand mark** carries Avito's four saturated dots —
green `#04E062`, blue `#00AAFF`, purple `#965EEB`, red `#FF4053` — and they appear
*only* inside the logo. Nothing else in the campaign is green or red.

The **campaign palette** is a single violet ramp on white, `#F6F3FE` through
`#8127EB` down to `#241A3D`, with pure black `#000000` for all type. There is no
secondary hue, no warm accent, no dark mode. Everything not violet is white.

Contrast comes from *saturation*, not hue: pale lavender washes carry the copy,
and the deep `#8127EB` appears only where the 3D artwork sits.

### Gradients — the load-bearing device

The system is gradient-driven, and every gradient runs **light → dark on one
axis**, never radial, never multi-hue, never blue-purple "AI" gradients:

- **Canvas wash** `--gradient-canvas` — 112°, white for the first 40% of the
  artboard (so type sits on paper), then `#F6F3FE → #E0D4F8 → #CDB0F8` under the
  artwork. Every banner and email header uses it.
- **Scene disc** `--gradient-scene` — 135°, `#F1EBFC → #A878FA`. The circular
  backdrop behind each 3D render.
- **Underline bar** `--gradient-underline` — 90°, `#9660EA → #E0C8F6`.
- **Pill ring** `--gradient-pill-stroke` — 135°, `#9761EB → #DFC8F6`.
- **Pill label** `--gradient-pill-text` — 90°, `#8151C9 → #020204`: violet
  dissolving into ink across the width of the word.

### Type

One geometric grotesque, two roles:
- **Display, weight 800** — headlines only, `-0.02em` tracking, line-height
  **1.02** (lines nearly touch). 72px on the 1400px canvas, 56px on the email
  header, 44px on square crops.
- **Text, weight 500** — all body copy, line-height 1.34, 24px on the 1400px
  canvas, 22px on the email header. No weight below 500 appears in the artwork.

Line breaks are **always manual**. Nothing in the package wraps automatically.

> **⚠ FONT SUBSTITUTION — needs your input.** No font files were supplied.
> The system ships **Manrope** (Google Fonts) under the family names
> `Avito Display` / `Avito Text`; it is a very close match to the artwork's
> letterforms but it is a substitution, not the licensed original. See
> *Caveats* below.

### The signature device: the underline bar

A fully-rounded 14px violet gradient bar tucked **6px below the baseline** of the
headline's last line, spanning exactly that line's width and passing *behind* the
descenders. It appears **exactly once per artboard**. It is the brand's whole
typographic identity — no other rule, keyline, divider or accent bar exists in the
system.

### Imagery

Every image is a **3D render**: soft studio lighting, matte plastic and brushed
chrome materials, a fine violet speckle/grain inside the saturated surfaces, and
stylised human characters with simplified features and green earrings. Colour
temperature is **cool** — violet, ice blue, chrome — broken exactly once, by a red
cardigan in the `parent-laptop` scene. No photography. No flat illustration. No
line art.

Two image roles:
- **Scenes** — 960×960 circular compositions (`assets/scenes/`), placed at the
  right of the canvas, oversized and **cropped by the artboard edge**. Never
  centred, never fully visible.
- **Objects** — cut-out renders on transparency (`assets/objects/`): a blue
  lightning bolt, a chrome magnifier, a lavender notepad with pen, a violet
  concentric disc, a skateboard with a football. Used **one or two at a time**,
  overlapping the scene's edge. The lightning bolt recurs in almost every
  composition, always upper-left of the scene.

### Layout

Fixed artboards, absolutely positioned, no responsive behaviour — this is
artwork, not a web page. Measured from the source files:

- Left inset **51px**, top inset **57px** (1400px canvas); 44 / 62 on the email header.
- Copy column pinned left, artwork pinned right and allowed to bleed off both the
  right and bottom edges.
- Vertical rhythm: logo → **45** → headline → **38** → body → **32** → pills.
- Logo height 70px (1400 canvas) / 84px (email header).
- Copy never overlaps artwork; the white 40% of the wash is the copy's safe area.

### Surfaces, borders, shadows, blur

- **No cards.** The system has no card component: no elevated container, no border
  box, no panel. Content sits directly on the canvas.
- **No drop shadows on anything.** All depth in the package is *rendered inside*
  the 3D artwork. `--shadow-object-soft` exists as an optional lift if you float
  an object over flat colour, but nothing in the source uses it.
- **No borders** except the outline pill's own 7px gradient ring — which is part
  of the shape, not a stroke on a box.
- **No blur, no glass, no transparency effects.** Everything is opaque. Objects are
  hard-keyed cut-outs, not feathered.
- **No protection gradients or capsules** behind type — the canvas wash keeps the
  copy area white so none is needed.

### Corner radii

`999px` pills, `24px` cards (for tooling built around the system, not the artwork),
`56px` on the rounded-square photo tiles inside the `tutor-cards` scene, and true
circles for scenes.

### Motion & interaction

The source material is entirely static. Conventions for anything built on top:
`140/220/400ms`, easing `cubic-bezier(.2,.6,.2,1)` — soft, no bounce, no overshoot.
Hover = **opacity .86** (never a colour change, never a shadow). Press =
**scale .98**. Nothing in this brand bounces or springs.

---

## ICONOGRAPHY

**There is no icon set in this brand, and none was invented for this system.**

The package contains no icon font, no SVG sprite, no PNG icon sheet, and no
repeated glyph system. What looks like iconography is actually **3D object
photography**: the lightning bolt, the magnifier, the notepad and the disc are
rendered props, shipped as transparent PNGs, used at illustration scale
(70–160px) rather than at icon scale.

- **Symbol vocabulary:** blue lightning bolt (the recurring campaign accent),
  chrome magnifier (search), spiral notepad + pen (study), violet concentric disc
  (a pure texture/backdrop element), skateboard + football (the schoolkid
  audience), four-pointed sparkle (rendered into some scenes, not a separate asset).
- **Small UI glyphs inside the renders** — the blue circled checkmarks on the
  checklist, the green "add person" badge on the book stack — exist *only* as
  pixels inside those PNGs. They are not extractable components. Do not try to
  reproduce them as vector icons.
- **No emoji, no Unicode glyphs used as icons.** The only non-letter characters in
  the copy are the em dash and the slash in ОГЭ/ЕГЭ.
- **If you need a functional UI icon** (a chevron, a close button) for tooling
  built around this brand, none exists in the source. Ask the brand owner rather
  than substituting a CDN set — a Lucide or Heroicons stroke icon next to these
  matte 3D props reads as a foreign object.

All extractable art has been copied into `assets/`; nothing here was drawn,
traced, or generated.

---

## Index

### Root
| File | What |
|---|---|
| `styles.css` | Global entry point — `@import` list only. Link this one file. |
| `readme.md` | This document. |
| `SKILL.md` | Agent-Skills front matter, for use in Claude Code. |
| `thumbnail.html` | Homepage tile for this design system. |

### Tokens — `tokens/`
`fonts.css` · `colors.css` · `typography.css` · `spacing.css` · `radius.css` ·
`gradients.css` · `effects.css` · `motion.css`

### Components — `components/`
| Component | Directory | What it is |
|---|---|---|
| **BrandLogo** | `components/brand/` | The Avito Услуги lockup, or the four-dot mark alone. |
| **HeadlineUnderline** | `components/typography/` | Display headline with the violet gradient bar. |
| **Pill** | `components/pills/` | Category pill, `outline` and `soft` variants. |
| **SceneCircle** | `components/illustration/` | Circular violet-gradient disc holding a 3D scene. |
| **ObjectSticker** | `components/illustration/` | A cut-out 3D object, absolutely positioned. |
| **PromoBanner** | `components/layout/` | The artboard, plus `PromoCopy`, `PromoBody`, `PromoPills`. |

Each directory carries `<Name>.jsx`, `<Name>.d.ts`, `<Name>.prompt.md` and one
`@dsCard` HTML.

**Component inventory is source-bound.** These six families are exactly what the
campaign package defines. There is no Button, Input, Card, Tabs, Toast or Avatar in
this system because the source contains none — the artwork has no interactive
elements at all.

**Intentional additions.** Email needs tappable targets, which the source artwork
has none of. The digest template therefore defines a **two-level button system**
built only from existing tokens, and nothing else:
- **primary** — solid `--violet-650` (#8127EB), white label, weight 800, radius 999. **One per block.**
- **secondary** — `--violet-200` (#DFCDF3) fill, `--violet-800` (#523381) label, weight 700, radius 999.

There is no third level and no other fill colour. If a row needs more than one
option, they are all secondary. Category chips use the secondary style verbatim.

### UI kits — `ui_kits/`
| Kit | What |
|---|---|
| `ui_kits/promo-banners/` | Six campaign concepts × three artboard sizes, with pill and lightning-bolt toggles. |
| `ui_kits/email-campaign/` | The «Шапка» email header in both audience cuts, inside a mail-client frame. Body blocks are left blank by design — they were not in the source. |

### Templates — `templates/`
| Template | What |
|---|---|
| `templates/campaign-banner/CampaignBanner.dc.html` | 1400×500 promo artboard, scene selectable. |
| `templates/email-header/EmailHeader.dc.html` | 1305×663 «Шапка» email header, scene selectable. |
| `templates/autumn-digest-email/AutumnDigestEmail.dc.html` | 600px CRM digest email — preheader, structured hero, article cards, category cards, promo banner, footer. Art is `<image-slot>` placeholders. |

Consuming projects: edit the `base` line in each template's `ds-base.js` to point
at the bound `_ds/<folder>` tree.

### Foundation cards — `guidelines/`
21 specimen cards feeding the Design System tab, grouped **Colors**, **Type**,
**Spacing**, **Brand**.

### Assets — `assets/`
`logo-avito-uslugi.png`, `logo-avito-mark.png` (extracted from the email header
and un-matted to transparency) · `objects/` (6 cut-out 3D renders) · `scenes/`
(6 circular 960×960 scenes) · `reference/` (10 original finished artboards, kept
for pixel comparison).

---

## Caveats & what we need from you

1. **Fonts.** No `.otf`/`.ttf`/`.woff2` was supplied. The system substitutes
   **Manrope** from Google Fonts under the family aliases `Avito Display` /
   `Avito Text`. Please send the licensed brand binaries so we can replace the
   `@font-face` sources in `tokens/fonts.css`.
2. **The logo is an extraction, not a master file.** `assets/logo-avito-uslugi.png`
   was lifted from `Шапка.jpg` at 536×84 and un-matted from white. It is raster and
   it is small. A vector master (`.svg`/`.ai`) would let the lockup scale.
3. **Email body is missing.** Only the header block was delivered. The email kit
   marks the rest blank rather than inventing tutor cards, CTAs or a footer.
4. **No interactive components exist in the source**, so none were authored. If
   this brand has a real product UI (the Avito app or web listing pages), that is
   a separate design system and would need its own source.
5. **Motion is inferred.** The package is static; the motion tokens are a
   reasonable convention, not observed behaviour.
