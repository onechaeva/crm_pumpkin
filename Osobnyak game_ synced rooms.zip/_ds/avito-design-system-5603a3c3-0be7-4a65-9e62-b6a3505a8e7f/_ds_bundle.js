/* @ds-bundle: {"format":4,"namespace":"AvitoDesignSystem_5603a3","components":[{"name":"BrandLogo","sourcePath":"components/brand/BrandLogo.jsx"},{"name":"ObjectSticker","sourcePath":"components/illustration/ObjectSticker.jsx"},{"name":"OBJECT_NAMES","sourcePath":"components/illustration/ObjectSticker.jsx"},{"name":"SceneCircle","sourcePath":"components/illustration/SceneCircle.jsx"},{"name":"PromoBanner","sourcePath":"components/layout/PromoBanner.jsx"},{"name":"PromoCopy","sourcePath":"components/layout/PromoBanner.jsx"},{"name":"PromoBody","sourcePath":"components/layout/PromoBanner.jsx"},{"name":"PromoPills","sourcePath":"components/layout/PromoBanner.jsx"},{"name":"Pill","sourcePath":"components/pills/Pill.jsx"},{"name":"HeadlineUnderline","sourcePath":"components/typography/HeadlineUnderline.jsx"}],"sourceHashes":{"components/brand/BrandLogo.jsx":"6b99e8551242","components/illustration/ObjectSticker.jsx":"1bc4fca9a94b","components/illustration/SceneCircle.jsx":"7c8bbf76514e","components/layout/PromoBanner.jsx":"58f481c421ae","components/pills/Pill.jsx":"769b0aa962bc","components/typography/HeadlineUnderline.jsx":"b61378ecefa8","ui_kits/email-campaign/EmailHeader.jsx":"422670ac4475","ui_kits/promo-banners/BannerScreen.jsx":"6ccbda924fce","ui_kits/promo-banners/CampaignData.js":"78f97c2af0e6"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AvitoDesignSystem_5603a3 = window.AvitoDesignSystem_5603a3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/BrandLogo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SRC = {
  lockup: "logo-avito-uslugi.png",
  mark: "logo-avito-mark.png"
};

/**
 * The Avito Услуги lockup, extracted from the source campaign artwork.
 * Always placed on white or the palest end of the violet wash — never on
 * saturated violet, and never recoloured.
 */
function BrandLogo({
  variant = "lockup",
  height = 70,
  assetBase = "assets",
  alt = "Avito Услуги",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("img", _extends({
    src: assetBase.replace(/\/$/, "") + "/" + SRC[variant],
    alt: alt,
    style: {
      height,
      width: "auto",
      display: "block",
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { BrandLogo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/BrandLogo.jsx", error: String((e && e.message) || e) }); }

// components/illustration/ObjectSticker.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const OBJECTS = {
  lightning: "objects/lightning.png",
  "lightning-sm": "objects/lightning-sm.png",
  magnifier: "objects/magnifier.png",
  notepad: "objects/notepad.png",
  disc: "objects/disc.png",
  "skate-ball": "objects/skate-ball.png"
};

/**
 * A single 3D render cut out on transparency, floated over a scene or the
 * canvas wash. Positioned absolutely by the caller.
 */
function ObjectSticker({
  name,
  width = 160,
  assetBase = "assets",
  rotate = 0,
  alt = "",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("img", _extends({
    src: assetBase.replace(/\/$/, "") + "/" + OBJECTS[name],
    alt: alt,
    style: {
      width,
      height: "auto",
      display: "block",
      transform: rotate ? `rotate(${rotate}deg)` : undefined,
      ...style
    }
  }, rest));
}
const OBJECT_NAMES = Object.keys(OBJECTS);
Object.assign(__ds_scope, { ObjectSticker, OBJECT_NAMES });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/illustration/ObjectSticker.jsx", error: String((e && e.message) || e) }); }

// components/illustration/SceneCircle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The circular illustration scene: a violet gradient disc carrying one of the
 * campaign's 3D renders. Used at full bleed on the right of wide banners and
 * as the whole composition in the 960×960 square crop.
 */
function SceneCircle({
  src,
  size = 500,
  alt = "",
  bleed = false,
  style,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      width: size,
      height: size,
      borderRadius: "var(--radius-circle)",
      overflow: bleed ? "visible" : "hidden",
      background: src ? "transparent" : "var(--gradient-scene)",
      flex: "0 0 auto",
      ...style
    }
  }, rest), src && /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block",
      borderRadius: "var(--radius-circle)"
    }
  }), children);
}
Object.assign(__ds_scope, { SceneCircle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/illustration/SceneCircle.jsx", error: String((e && e.message) || e) }); }

// components/layout/PromoBanner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The campaign canvas: fixed-ratio artboard with the white→violet wash,
 * copy stacked at the left inset and artwork bleeding off the right.
 */
function PromoBanner({
  width = 1400,
  height = 500,
  children,
  wash = true,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      width,
      height,
      overflow: "hidden",
      background: wash ? "var(--gradient-canvas)" : "var(--surface-page)",
      fontFamily: "var(--font-text)",
      color: "var(--text-body)",
      ...style
    }
  }, rest), children);
}

/** Left-hand copy column: logo, headline, body, pills — in that order. */
function PromoCopy({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "absolute",
      left: "var(--canvas-inset-x)",
      top: "var(--canvas-inset-y)",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      zIndex: 2,
      ...style
    }
  }, rest), children);
}

/** Subhead under the headline. Two or three short lines, broken by hand. */
function PromoBody({
  children,
  size = "var(--size-body-l)",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("p", _extends({
    style: {
      margin: 0,
      fontFamily: "var(--font-text)",
      fontWeight: "var(--weight-medium)",
      fontSize: size,
      lineHeight: "var(--leading-body)",
      color: "var(--text-body)",
      ...style
    }
  }, rest), children);
}

/** Row of category pills. */
function PromoPills({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      gap: "var(--pill-gap)",
      alignItems: "center",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { PromoBanner, PromoCopy, PromoBody, PromoPills });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/PromoBanner.jsx", error: String((e && e.message) || e) }); }

// components/pills/Pill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * The campaign's category pill. Two variants only, both taken from the email
 * header artwork: an `outline` pill (white fill, thick violet gradient ring,
 * ink label) and a `soft` pill (lavender fill, violet→ink gradient label).
 */
function Pill({
  children,
  variant = "outline",
  size = 26,
  ringWidth = 7,
  style,
  ...rest
}) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    fontFamily: "var(--font-display)",
    fontWeight: "var(--weight-extrabold)",
    fontSize: size,
    lineHeight: 1,
    letterSpacing: "-0.01em",
    padding: `${Math.round(size * 0.62)}px ${Math.round(size * 1.15)}px`,
    borderRadius: "var(--radius-pill)",
    whiteSpace: "nowrap"
  };
  if (variant === "soft") {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        ...base,
        background: "var(--surface-soft)",
        color: "var(--violet-700)",
        backgroundImage: "var(--surface-soft)",
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      style: {
        backgroundImage: "var(--gradient-pill-text)",
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        color: "transparent"
      }
    }, children));
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      color: "var(--ink)",
      background: "var(--gradient-pill-stroke)",
      padding: ringWidth,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--white)",
      borderRadius: "var(--radius-pill)",
      padding: `${Math.round(size * 0.62) - ringWidth + 4}px ${Math.round(size * 1.15) - ringWidth}px`
    }
  }, children));
}
Object.assign(__ds_scope, { Pill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/pills/Pill.jsx", error: String((e && e.message) || e) }); }

// components/typography/HeadlineUnderline.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Campaign headline with the signature violet gradient bar sitting under the
 * last line. The bar is drawn as a background layer so it tucks behind the
 * descenders exactly as in the source artwork.
 */
function HeadlineUnderline({
  children,
  size = "var(--size-display-xl)",
  barHeight = "var(--underline-height)",
  lift = "var(--underline-lift)",
  underline = true,
  as: Tag = "h1",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontWeight: "var(--weight-extrabold)",
      fontSize: size,
      lineHeight: "var(--leading-display)",
      letterSpacing: "var(--tracking-display)",
      color: "var(--text-heading)",
      isolation: "isolate",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline"
    }
  }, underline && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: `calc(-1 * (${lift}))`,
      height: barHeight,
      borderRadius: "var(--radius-pill)",
      background: "var(--gradient-underline)",
      zIndex: -1
    }
  }), children));
}
Object.assign(__ds_scope, { HeadlineUnderline });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/typography/HeadlineUnderline.jsx", error: String((e && e.message) || e) }); }

// ui_kits/email-campaign/EmailHeader.jsx
try { (() => {
const {
  PromoBanner,
  PromoCopy,
  PromoBody,
  PromoPills,
  BrandLogo,
  HeadlineUnderline,
  Pill,
  SceneCircle,
  ObjectSticker
} = window.AvitoDesignSystem_5603a3;
const A = "../../assets";

/** The «Шапка» — the only email block present in the source campaign. 1305×663. */
function EmailHeader({
  variant
}) {
  return /*#__PURE__*/React.createElement(PromoBanner, {
    width: 1305,
    height: 663
  }, /*#__PURE__*/React.createElement(SceneCircle, {
    bleed: true,
    src: A + "/scenes/" + variant.scene + ".png",
    size: 760,
    style: {
      position: "absolute",
      right: -130,
      top: -50
    }
  }, /*#__PURE__*/React.createElement(ObjectSticker, {
    name: "lightning",
    assetBase: A,
    width: 128,
    style: {
      position: "absolute",
      left: -66,
      top: 150
    }
  })), /*#__PURE__*/React.createElement(PromoCopy, {
    style: {
      left: 44,
      top: 62
    }
  }, /*#__PURE__*/React.createElement(BrandLogo, {
    assetBase: A,
    height: 84
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 54
    }
  }), /*#__PURE__*/React.createElement(HeadlineUnderline, {
    size: "var(--size-display-m)",
    barHeight: "13px",
    lift: "5px"
  }, variant.head.map((l, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("br", null), l))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 50
    }
  }), /*#__PURE__*/React.createElement(PromoBody, {
    size: "22px"
  }, variant.body.map((l, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("br", null), l))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 46
    }
  }), /*#__PURE__*/React.createElement(PromoPills, null, /*#__PURE__*/React.createElement(Pill, {
    variant: "outline"
  }, variant.pills[0]), /*#__PURE__*/React.createElement(Pill, {
    variant: "soft"
  }, variant.pills[1]))));
}
const EMAIL_VARIANTS = [{
  id: "parents",
  audience: "Родители",
  subject: "Подготовка к экзаменам",
  head: ["Подготовка", "к экзаменам"],
  body: ["Самое время обратиться к репетитору", "и прокачать знания по нужным предметам"],
  pills: ["Репетитор", "ОГЭ/ЕГЭ"],
  scene: "scene-hourglass-notes"
}, {
  id: "schoolkids",
  audience: "Школьники",
  subject: "Репетиторы к экзаменам",
  head: ["Репетиторы", "к экзаменам"],
  body: ["Посмотрите объявления и выберите", "преподавателя для ребёнка"],
  pills: ["Репетитор", "ОГЭ/ЕГЭ"],
  scene: "scene-teen-phone"
}];
Object.assign(window, {
  EmailHeader,
  EMAIL_VARIANTS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/email-campaign/EmailHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/promo-banners/BannerScreen.jsx
try { (() => {
const {
  PromoBanner,
  PromoCopy,
  PromoBody,
  PromoPills,
  BrandLogo,
  HeadlineUnderline,
  Pill,
  SceneCircle,
  ObjectSticker
} = window.AvitoDesignSystem_5603a3;
const A = "../../assets";
function BannerScreen({
  campaign,
  format,
  showBolt = true,
  showPills = false
}) {
  const fmt = window.FORMATS[format];
  const src = A + "/scenes/" + campaign.scene + ".png";
  if (fmt.artOnly) {
    return /*#__PURE__*/React.createElement(PromoBanner, {
      width: fmt.w,
      height: fmt.h,
      wash: false,
      style: {
        background: "var(--white)"
      }
    }, /*#__PURE__*/React.createElement(SceneCircle, {
      src: src,
      size: fmt.scene
    }));
  }
  const lines = campaign.head;
  return /*#__PURE__*/React.createElement(PromoBanner, {
    width: fmt.w,
    height: fmt.h
  }, /*#__PURE__*/React.createElement(SceneCircle, {
    bleed: true,
    src: src,
    size: fmt.scene,
    style: {
      position: "absolute",
      right: fmt.sx,
      top: fmt.sy
    }
  }, showBolt && /*#__PURE__*/React.createElement(ObjectSticker, {
    name: "lightning",
    assetBase: A,
    width: fmt.scene * 0.18,
    style: {
      position: "absolute",
      left: -fmt.scene * 0.1,
      top: fmt.scene * 0.22
    }
  })), /*#__PURE__*/React.createElement(PromoCopy, {
    style: {
      top: fmt.h === 712 ? 76 : "var(--canvas-inset-y)"
    }
  }, /*#__PURE__*/React.createElement(BrandLogo, {
    assetBase: A,
    height: fmt.logo
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: fmt.h === 712 ? 74 : 45
    }
  }), /*#__PURE__*/React.createElement(HeadlineUnderline, {
    size: fmt.head
  }, lines.map((l, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("br", null), l))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: fmt.h === 712 ? 46 : 38
    }
  }), /*#__PURE__*/React.createElement(PromoBody, {
    size: fmt.body
  }, campaign.body.map((l, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("br", null), l))), showPills && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 32
    }
  }), /*#__PURE__*/React.createElement(PromoPills, null, /*#__PURE__*/React.createElement(Pill, {
    variant: "outline"
  }, campaign.pills[0]), /*#__PURE__*/React.createElement(Pill, {
    variant: "soft"
  }, campaign.pills[1])))));
}
Object.assign(window, {
  BannerScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/promo-banners/BannerScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/promo-banners/CampaignData.js
try { (() => {
window.CAMPAIGNS = [{
  id: "ekzameny-blizko",
  head: ["Экзамены", "близко"],
  body: ["Самое время выбрать репетитора", "и помочь ребёнку в подготовке", "к ОГЭ или ЕГЭ"],
  scene: "scene-teen-phone",
  pills: ["Репетитор", "ОГЭ/ЕГЭ"]
}, {
  id: "sezon",
  head: ["Сезон экзаменов"],
  body: ["Если хочется подтянуть знания", "по школьным предметам, найти", "репетитора можно на Авито Услугах"],
  scene: "scene-calendar-magnifier",
  pills: ["Репетитор", "Школьные предметы"]
}, {
  id: "pered",
  head: ["Перед", "экзаменами"],
  body: ["Ещё есть время найти репетитора", "для ребёнка, чтобы подтянуть знания"],
  scene: "scene-tutor-cards",
  pills: ["Репетитор", "ОГЭ/ЕГЭ"]
}, {
  id: "za-znaniyami",
  head: ["За знаниями"],
  body: ["Самое время выбрать репетитора", "для подготовки к ОГЭ и ЕГЭ"],
  scene: "scene-books",
  pills: ["Репетитор", "Подготовка"]
}, {
  id: "nayti-repetitora",
  head: ["Найти", "репетитора"],
  body: ["Если ребёнку нужно готовиться", "к экзаменам, преподавателя можно", "выбрать на Авито Услугах"],
  scene: "scene-parent-laptop",
  pills: ["Репетитор", "ОГЭ/ЕГЭ"]
}, {
  id: "skoro",
  head: ["Скоро", "экзамены"],
  body: ["Ещё есть время найти репетитора", "и подготовиться к школьным предметам"],
  scene: "scene-hourglass-notes",
  pills: ["Репетитор", "ОГЭ/ЕГЭ"]
}];
window.FORMATS = {
  "1400x500": {
    w: 1400,
    h: 500,
    logo: 70,
    head: "var(--size-display-xl)",
    body: "var(--size-body-l)",
    scene: 640,
    sx: -70,
    sy: -80,
    pills: false
  },
  "1400x712": {
    w: 1400,
    h: 712,
    logo: 84,
    head: "var(--size-display-xl)",
    body: "var(--size-body-l)",
    scene: 760,
    sx: -90,
    sy: -30,
    pills: false
  },
  "960x960": {
    w: 960,
    h: 960,
    artOnly: true,
    scene: 960,
    sx: 0,
    sy: 0
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/promo-banners/CampaignData.js", error: String((e && e.message) || e) }); }

__ds_ns.BrandLogo = __ds_scope.BrandLogo;

__ds_ns.ObjectSticker = __ds_scope.ObjectSticker;

__ds_ns.OBJECT_NAMES = __ds_scope.OBJECT_NAMES;

__ds_ns.SceneCircle = __ds_scope.SceneCircle;

__ds_ns.PromoBanner = __ds_scope.PromoBanner;

__ds_ns.PromoCopy = __ds_scope.PromoCopy;

__ds_ns.PromoBody = __ds_scope.PromoBody;

__ds_ns.PromoPills = __ds_scope.PromoPills;

__ds_ns.Pill = __ds_scope.Pill;

__ds_ns.HeadlineUnderline = __ds_scope.HeadlineUnderline;

})();
